@extends("layout.admin")

@section("title")
    ASSESSMENTS
@endsection

@section("content")
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel" style="margin:5%">
                <b>Question &nbsp;{{Session::get("num")}}&nbsp;::
                <br />{{$question->question}}</b><br /><br />
                <form action="{{url('/admin/saveanswer')}}" method="POST"  class="form-horizontal">
                    {{ csrf_field() }}
                    <input type="hidden" name="correct"  value="{{$question->correct}}" >
                    <input type="radio" name="ans" value="{{$question->one}}" required>&nbsp;{{$question->one}}<br /><br />
                    <input type="radio" name="ans" value="{{$question->two}}" required>&nbsp;{{$question->two}}<br /><br />
                    <input type="radio" name="ans" value="{{$question->three}}" required>&nbsp;{{$question->three}}<br /><br />
                    <input type="radio" name="ans" value="{{$question->four}}" required>&nbsp;{{$question->four}}<br /><br /><br />
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span>&nbsp;Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection