@extends("layout.admin")

@section("title")
    DASHBOARD
@endsection

@section("content")
<div class="container"><!--container start-->
    <div class="row">
        <div class="col-md-12">
        <!--home start-->
        <!--home closed-->
        <!--users start-->
        <!--user end-->
        <!--feedback start-->
        <div class="panel"><div class="table-responsive"><table class="table table-striped title1">
        <tr><td><b>S.N.</b></td><td><b>Subject</b></td><td><b>Email</b></td><td><b>Date</b></td><td><b>Time</b></td><td><b>By</b></td><td></td><td></td></tr><tr><td>1</td><td><a title="Click to open feedback" href="dash.php?q=3&fid=62416c3e66064"></a></td><td></td><td>28-03-2022</td><td>10:05:18am</td><td></td>
            <td><a title="Open Feedback" href="dash.php?q=3&fid=62416c3e66064"><b><span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span></b></a></td><td><a title="Delete Feedback" href="update.php?fdid=62416c3e66064"><b><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></b></a></td>

            </tr><tr><td>2</td><td><a title="Click to open feedback" href="dash.php?q=3&fid=5eb7beb3bf632"></a></td><td></td><td>10-05-2020</td><td>10:43:31am</td><td>Grade 12 - Class 2</td>
            <td><a title="Open Feedback" href="dash.php?q=3&fid=5eb7beb3bf632"><b><span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span></b></a></td><td><a title="Delete Feedback" href="update.php?fdid=5eb7beb3bf632"><b><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></b></a></td>

            </tr></table></div>
        </div><!--feedback closed-->

    <!--feedback reading portion start-->
    <!--Feedback reading portion closed-->

    <!--add quiz start-->
    <!--add quiz end-->

    <!--add quiz step2 start-->
    <!--add quiz step 2 end-->

    <!--remove quiz-->
</div><!--container closed-->
@endsection