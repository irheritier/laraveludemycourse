

<?php $__env->startSection('title'); ?>
    Customer Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card w-100 text-center shadowBlue">
      <div class="card-header">
        Account profile for Fayyaz Khan<kbd>#1513410837</kbd>  
      </div>
      <div class="card-body bg-dark text-white">
        <div class="text-center">
          <img src="/storage/account_images/<?php echo e($account->photo); ?>" height="100" width="100" alt="" class="rounded-circle m-2" style="border : 2px solid#FFF;">
      </div>
        <table class="table table-bordered">
          <tbody>
            <tr>
              <td>Name</td>
              <th><?php echo e($account->name); ?></th>
              <td>Account No</td>
              <th><?php echo e($account->accountnumber); ?></th>
            </tr><tr>
              <td>Branch Name</td>
              <th><?php echo e($account->branchname); ?></th>
              <td>Brach Code</td>
              <th><?php echo e($account->branchcode); ?></th>
            </tr><tr>
              <td>Current Balance</td>
              <th><?php echo e($account->balance); ?></th>
              <td>Account Type</td>
              <th><?php echo e($account->accounttype); ?></th>
            </tr><tr>
              <td>Cnic</td>
              <th><?php echo e($account->cnic); ?></th>
              <td>City</td>
              <th><?php echo e($account->city); ?></th>
            </tr><tr>
              <td>Contact Number</td>
              <th><?php echo e($account->phone); ?></th>
              <td>Address</td>
              <th><?php echo e($account->address); ?></th>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="card-footer text-muted">
        MCB Bank  </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank\resources\views/manager/customerdetails.blade.php ENDPATH**/ ?>