

<?php $__env->startSection("title"); ?>
    Test Your Skill
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="container"><!--container start-->
        <div class="row">
            <div class="col-md-12">
                <div class="panel title">
                    <table class="table table-striped title1" >
                        <tr style="color:red">
                            <td><b>S.N.</b></td>
                            <td><b>Quiz</b></td>
                            <td><b>Question Solved</b></td>
                            <td><b>Right</b></td>
                            <td><b>Wrong<b></td>
                            <td><b>Score</b></td>
                            <input type="hidden" <?php echo e($increment = 1); ?> >
                        </tr> 
                        <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($increment); ?></td>
                                <td><?php echo e($score->topic); ?></td>
                                <td><?php echo e(($score->score)/($score->mark)); ?></td>
                                <td><?php echo e(($score->score)/($score->mark)); ?></td>
                                <td><?php echo e($score->numquestion - (($score->score)/($score->mark))); ?></td>
                                <td><?php echo e($score->score); ?></td>
                            </tr>
                            <input type="hidden" <?php echo e($increment++); ?> >
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examination\resources\views/user/history.blade.php ENDPATH**/ ?>