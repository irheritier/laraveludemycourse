

<?php $__env->startSection('title'); ?>
    Feedback
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card w-100 text-center shadowBlue">
    <div class="card-header">
      Feedback from Account Holder
    </div>
    <div class="card-body">
     <table class="table table-bordered table-sm bg-dark text-white">
    <thead>
      <tr>
        <th scope="col">From</th>
        <th scope="col">Account No.</th>
        <th scope="col">Contact</th>
        <th scope="col">Message</th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($feedback->name); ?></td>
          <td><?php echo e($feedback->accountnumber); ?></td>
          <td><?php echo e($feedback->phone); ?></td>
          <td><?php echo e($feedback->message); ?></td>
          <td>
            <a href="" class='btn btn-danger btn-sm' data-toggle='tooltip' title="Delete this Message">Delete</a>
          </td>
        </tr>    
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
    <div class="card-footer text-muted">
      MCB Bank  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank\resources\views/manager/feedback.blade.php ENDPATH**/ ?>