

<?php $__env->startSection("title"); ?>
    Test Your Skill
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="container"><!--container start-->
        <div class="row">
            <div class="col-md-12">
                <div class="panel">
                    <div class="table-responsive">
                        <table class="table table-striped title1">
                        <tr>
                            <td><b>S.N.</b></td>
                            <td><b>Topic</b></td>
                            <td><b>Total question</b></td>
                            <td><b>Marks</b></td>
                            <td><b>Time limit</b></td>
                            <td></td>
                        </tr>
                        <input type="hidden" <?php echo e($increment = 1); ?> >
                            <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quizze): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" <?php echo e($restart = 0); ?> >
                                    <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(Session::get('developer')->email == $score->email &&$quizze->topic == $score->topic): ?>
                                            <input type="hidden" <?php echo e($restart++); ?> >
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($restart == 1): ?>
                                        <tr style="color:#99cc32">
                                            <td><?php echo e($increment); ?></td>
                                            <td><?php echo e($quizze->topic); ?>&nbsp;<span title="This quiz is already solve by you" class="glyphicon glyphicon-ok" aria-hidden="true"></span></td>
                                            <td><?php echo e($quizze->numquestion); ?></td>
                                            <td><?php echo e($quizze->mark); ?></td>
                                            <td><?php echo e($quizze->timelimit); ?>&nbsp;min</td>
                                            <td><b><a href="/user/respond/<?php echo e($quizze->topic); ?>" class="pull-right btn sub1" style="margin:0px;background:red"><span class="glyphicon glyphicon-repeat" aria-hidden="true"></span>&nbsp;<span class="title1"><b>Restart</b></span></a></b></td>
                                        </tr>
                                    <?php else: ?>
                                        <tr>
                                            <td><?php echo e($increment); ?></td>
                                            <td><?php echo e($quizze->topic); ?></td>
                                            <td><?php echo e($quizze->numquestion); ?></td>
                                            <td><?php echo e($quizze->mark); ?></td>
                                            <td><?php echo e($quizze->timelimit); ?>&nbsp;min</td>
                                            <td><b><a href="/user/respond/<?php echo e($quizze->topic); ?>" class="pull-right btn sub1" style="margin:0px;background:#99cc32"><span class="glyphicon glyphicon-new-window" aria-hidden="true"></span>&nbsp;<span class="title1"><b>Start</b></span></a></b></td>
                                        </tr>
                                    <?php endif; ?>
                                
                                <input type="hidden" <?php echo e($increment++); ?> >   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examination\resources\views/user/takequiz.blade.php ENDPATH**/ ?>