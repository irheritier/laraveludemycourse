<!DOCTYPE html>
<html>
<head>
  <title><?php echo $__env->yieldContent('title'); ?></title>
  
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('style/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('style/css/custom.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('style/font-awesome/css/font-awesome.min.css')); ?>">
<script src='<?php echo e(asset('style/js/jquery-3.2.1.min.js')); ?>'></script>
<script src='<?php echo e(asset('style/js/popper.min.js')); ?>'></script>
<script src='<?php echo e(asset('style/js/bootstrap.min.js')); ?>'></script>

<script type="text/javascript">
	$(function () {
  $('[data-toggle="tooltip"]').tooltip()
});
</script>    </head>
<body style="background:#96D678;background-size: 100%">

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">

    <?php echo $__env->yieldContent('content'); ?>

    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\bank\resources\views/layout/master.blade.php ENDPATH**/ ?>