

<?php $__env->startSection("title"); ?>
    RESULT
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container"><!--container start-->
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <center><h1 class="title" style="color:#660033">Result</h1><center><br />
                <table class="table table-striped title1" style="font-size:20px;font-weight:1000;">
                <tr style="color:#66CCFF">
                    <td>Total Questions</td>
                    <td><?php echo e($score->numquestion); ?></td>
                </tr>
                <tr style="color:#99cc32">
                    <td>right Answer&nbsp;<span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span></td>
                    <td><?php echo e(($score->score)/$score->mark); ?></td>
                </tr> 
                <tr style="color:red">
                    <td>Wrong Answer&nbsp;<span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span></td>
                    <td><?php echo e(($score->numquestion)-(($score->score)/$score->mark)); ?></td>
                </tr>
                <tr style="color:#66CCFF">
                    <td>Score&nbsp;<span class="glyphicon glyphicon-star" aria-hidden="true"></span></td>
                    <td><?php echo e($score->score); ?></td>
                </tr>
                <tr style="color:#990000">
                    <td>Overall Score&nbsp;<span class="glyphicon glyphicon-stats" aria-hidden="true"></span></td>
                    <td>-1</td>
                </tr>
                </table>
            </div><!--quiz end-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examination\resources\views/user/results.blade.php ENDPATH**/ ?>