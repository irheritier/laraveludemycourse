;

<?php $__env->startSection('title'); ?>
    Transaction
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row w-100" style="padding: 11px">
    <div class="col">
      <div class="card text-center w-75 mx-auto">
    <div class="card-header">
      Account Information
    </div>
    <div class="card-body">
              <div class="row">
                    <div class="col">
                    
                      Account No.
                      <input type="text" value="<?php echo e($account->accountnumber); ?>" name="otherNo" class="form-control " readonly="" required="">
                      Account Holder Name.
                      <input type="text" class="form-control" value="<?php echo e($account->name); ?>" readonly="" required="">
                      Account Holder Bank Name.
                      <input type="text" class="form-control" value="<?php echo e($account->branchname); ?>" readonly="" required="">Bank Balance
                      <input type="text" class="form-control my-1" value="<?php echo e("$ ".$account->balance); ?>" readonly="" required="">
                       
                    
                    </div>
                    <div class="col">
                      Transaction Process.
                        <form action="<?php echo e(url("/cashier/customerwithdraw")); ?> " method="POST">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" value="<?php echo e($account->accountnumber); ?>" name="accountnumber" class="form-control " required=""> 

                            <input type="hidden" value="<?php echo e($account->name); ?>" name="name" class="form-control " required=""> 

                            <div class="form-group">
                                <input type="number" class="form-control my-1" name="amount" placeholder="Write Amount for withdraw" max="<?php echo e($account->balance); ?>" required="">
                            </div>                                                           
                            <button type="submit" name="withdraw" class="btn btn-primary btn-bloc btn-sm my-1"> Withdraw</button>
                        </form>
                          
                        <form action="<?php echo e(url("/cashier/cashierdeposit")); ?> " method="POST"> 
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" value="<?php echo e($account->accountnumber); ?>" name="accountnumber" class="form-control " required="">

                            <input type="hidden" value="<?php echo e($account->name); ?>" name="name" class="form-control " required=""> 

                            <div class="form-group">
                                <input type="number" class="form-control my-1" name="amount" placeholder="Write Amount for deposit" required="">
                            </div>
                            <button type="submit" name="deposit" class="btn btn-success btn-bloc btn-sm my-1"> Deposit</button>
                    </form>
                    </div>
                  </div>
                </div>
    <div class="card-footer text-muted">
      MCB Bank  </div>
  </div>
    </div>
    
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank\resources\views/cashier/transaction.blade.php ENDPATH**/ ?>