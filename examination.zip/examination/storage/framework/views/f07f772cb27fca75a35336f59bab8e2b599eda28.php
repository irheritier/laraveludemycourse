

<?php $__env->startSection("title"); ?>
    DASHBOARD
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="row">
        <span class="title1" style="margin-left:40%;font-size:30px;"><b>Enter Question Details</b></span><br /><br />
        <div class="col-md-3"></div>
        <div class="col-md-6">
          <form class="form-horizontal title1" name="form" action="<?php echo e(url('/admin/savequestion')); ?>"  method="POST">
            <?php echo e(csrf_field()); ?>

              <b>Question number&nbsp;<?php echo e($quiz->num+1); ?>&nbsp;:</b><br/>
              <div class="form-group">
                <label class="col-md-12 control-label" for="qns1 "></label>  
                <div class="col-md-12">
                <textarea rows="3" cols="5" name="question" class="form-control" placeholder="Write question number <?php echo e($quiz->num); ?> here..." required></textarea>  
                </div>
              </div>
              <!-- Text input-->
              <div class="form-group">
                <label class="col-md-12 control-label" for="11"></label>  
                <div class="col-md-12">
                <input id="11" name="optiona" placeholder="Enter option a" class="form-control input-md" type="text" required>
                  
                </div>
              </div>
              <!-- Text input-->
              <div class="form-group">
                <label class="col-md-12 control-label" for="12"></label>  
                <div class="col-md-12">
                <input id="12" name="optionb" placeholder="Enter option b" class="form-control input-md" type="text" required>
                  
                </div>
              </div>
              <!-- Text input-->
              <div class="form-group">
                <label class="col-md-12 control-label" for="13"></label>  
                <div class="col-md-12">
                <input id="13" name="optionc" placeholder="Enter option c" class="form-control input-md" type="text" required>
                  
                </div>
              </div>
              <!-- Text input-->
              <div class="form-group">
                <label class="col-md-12 control-label" for="14"></label>  
                <div class="col-md-12">
                <input id="14" name="optiond" placeholder="Enter option d" class="form-control input-md" type="text" required>
                  
                </div>
              </div>
              <br />
              <b>Correct answer</b>:<br />
              <select id="ans1" name="answer" placeholder="Choose correct answer " class="form-control input-md" required>
                <option value="">Select answer for question <?php echo e($quiz->num+1); ?></option>
                <option value="a">option a</option>
                <option value="b">option b</option>
                <option value="c">option c</option>
                <option value="d">option d</option> 
              </select><br /><br />
              <div class="form-group">
                <label class="col-md-12 control-label" for=""></label>
                <div class="col-md-12"> 
                  <input  type="submit" style="margin-left:45%" class="btn btn-primary" value="Submit" class="btn btn-primary"/>
                </div>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examination\resources\views/admin/questiondetails.blade.php ENDPATH**/ ?>