

<?php $__env->startSection('title'); ?>
    Notice
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card w-100 text-center shadowBlue">
        <div class="card-header">
            Send Notice to <?php echo e($account->name); ?>  
        </div>
      <div class="card-body">
        <form action="<?php echo e(url('/manager/sendnotice')); ?> " method="POST">
            <?php echo e(csrf_field()); ?>

              <div class="alert alert-success w-50 mx-auto">
                <h5>Write notice for <?php echo e($account->name); ?></h5>
                <?php if(Session::has("status")): ?>
                    <?php echo e(Session::get("status")); ?>

                <?php endif; ?>
                <input type="hidden" value="<?php echo e($account->accountnumber); ?>" name="accountnumber">
                <textarea class="form-control" name="notice" required placeholder="Write your message"></textarea>
                <button type="submit" name="send" class="btn btn-primary btn-block btn-sm my-1">Send</button>
              </div>
          </form>  
      </div>
    <div class="card-footer text-muted">
        MCB Bank 
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank\resources\views/manager/notice.blade.php ENDPATH**/ ?>