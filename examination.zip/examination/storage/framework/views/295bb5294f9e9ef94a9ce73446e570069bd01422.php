<!DOCTYPE html>
<html>

    <head>

        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Project Worlds || <?php echo $__env->yieldContent("title"); ?> </title>
        <link  rel="stylesheet" href="<?php echo e(asset('style/css/bootstrap.min.css')); ?>"/>
        <link  rel="stylesheet" href="<?php echo e(asset('style/css/bootstrap-theme.min.css')); ?>"/>    
        <link rel="stylesheet" href="<?php echo e(asset('style/css/main.css')); ?>">
        <link  rel="stylesheet" href="<?php echo e(asset('style/css/font.css')); ?>">
        <script src="<?php echo e(asset('style/js/jquery.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('style/js/bootstrap.min.js')); ?>"  type="text/javascript"></script>
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>

    </head>

    <body  style="background:#eee;">
        <?php echo $__env->make("layout.navuser", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- start content -->
            <?php echo $__env->yieldContent("content"); ?>
        <!-- end content -->
        <!-- start footer -->
        <?php echo $__env->make("layout.footeruser", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end footer -->
    <!-- </div></div> -->
    </body>
</html><?php /**PATH C:\xampp\htdocs\examination\resources\views/layout/user.blade.php ENDPATH**/ ?>