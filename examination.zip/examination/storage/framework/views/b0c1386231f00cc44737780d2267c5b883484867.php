

<?php $__env->startSection("title"); ?>
    Test Your Skill
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="container"><!--container start-->
        <div class="row">
            <div class="col-md-12">
                <div class="panel title">
                    <div class="table-responsive">
                        <table class="table table-striped title1" >
                            <tr style="color:red">
                                <td><b>Rank</b></td>
                                <td><b>Name</b></td>
                                <td><b>Gender</b></td>
                                <td><b>College</b></td>
                                <td><b>Score</b></td>
                            </tr><br />
                            <input type="hidden" <?php echo e($increment=1); ?> >
                            <?php $__currentLoopData = $developers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="color:#99cc32"><b><?php echo e($increment); ?></b></td>
                                    <td><?php echo e($developer->name); ?></td>
                                    <td><?php echo e($developer->gender); ?></td>
                                    <td><?php echo e($developer->college); ?></td>
                                    <td><?php echo e($developer->score); ?></td>
                                    <td></td>
                                </tr>
                                <input type="hidden" <?php echo e($increment++); ?> >
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examination\resources\views/user/ranking.blade.php ENDPATH**/ ?>