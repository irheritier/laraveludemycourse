<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Quiz;
use App\Models\Question;
use App\Models\Score;
use App\Models\Developer;

class AdminController extends Controller
{
    //

    public function dashboard(){
        $quizzes = Quiz::All();
        $scores = Score::where('email', Session::get('admin')->email)->get();
        return view('admin.dashboard')->with("quizzes", $quizzes)->with('scores', $scores);
    }

    public function users(){
        $developers = Developer::get();
        return view('admin.users')->with('developers', $developers);
    }

    public function ranking(){
        $developers = Developer::orderBy('score', 'desc')->get();
        return view('admin.ranking')->with('developers', $developers);
    }

    public function feedback(){
        return view('admin.feedback');
    }

    public function quizdetails(){
        return view('admin.quizdetails');
    }

    public function savequiz(Request $request){
        $quiz = new Quiz();
        $quiz->topic = $request->input('topic');
        $quiz->numquestion = $request->input('numquestion');
        $quiz->mark = $request->input('mark');
        $quiz->timelimit = $request->input('timelimit');
        $quiz->description = $request->input('description');
        $quiz->num = 0;

        $quiz->save();

        $quiz = Quiz::where('topic', $request->input('topic'))->first();
        Session::put('quiz', $quiz);

        return redirect('/admin/questiondetails');
    }

    public function questiondetails(){
        $quiz = Quiz::where('topic', Session::get('quiz')->topic)->first();

        if($quiz->num < $quiz->numquestion){
            return view('admin.questiondetails')->with('quiz', $quiz);
        }
        else{
            Session::forget('quiz');
            return redirect("/admin/dashboard");
        }
    }

    public function savequestion(Request $request){
        
        $correct;

        if($request->input('answer') == "a"){
            $correct = $request->input('optiona');
        }
        elseif($request->input('answer') == "b"){
            $correct = $request->input('optionb');
        }
        elseif($request->input('answer') == "c"){
            $correct = $request->input('optionc');
        }
        else{
            $correct = $request->input('optiond');
        }

        $question = new Question();
        $question->topic = Session::get('quiz')->topic;
        $question->question = $request->input('question');
        $question->one = $request->input('optiona');
        $question->two = $request->input('optionb');
        $question->three = $request->input('optionc');
        $question->four = $request->input('optiond');
        $question->correct = $correct;


        $quiz = Quiz::where("topic", Session::get('quiz')->topic)->first();
        $quiz->num = $quiz->num + 1;
        $quiz->update();

        $question->numquestion = $quiz->num;
        $question->save();

        return redirect("/admin/questiondetails");
    }

    public function removequiz(){
        return view('admin.removequiz');
    }

    public function respondquestion($topic){

        if(!Session::get('num') && !Session::get('quiz')){
            Session::put('num', 1);

            $quiz = Quiz::where('topic', $topic)->first();
            Session::put("quiz", $quiz);
        }

        return redirect("/admin/assessments");

    }

    public function respondquestion1(){
        $num = Session::get('num') + 1;
        Session::forget('num');
        Session::put('num', $num);
       
        if($num <= Session::get('quiz')->num){
            return redirect("/admin/assessments");
        }
        else{
            Session::forget('num');
            Session::forget('score');
            return redirect("/admin/results");
        }
    }

    public function assessments(){
        if(Session::get("num")){
            $question = Question::where("topic", Session::get("quiz"))->where("numquestion", Session::get("num"))->first();

            return view("admin.assessments")->with("question", $question);
        }
        else{
            return redirect("/admin/dashboard");
        }
    }

    public function saveanswer(Request $request){
        $score = Score::where('email', Session::get('admin')->email)->where('topic', Session::get('quiz')->topic)->first();
        
        if($request->ans == $request->correct){
            if(!Session::get('score')){
                
                Session::put('score', Session::get('quiz')->mark);
            }
            else{
                $sc = Session::get('score');
                Session::forget('score');
                Session::put('score', Session::get('quiz')->mark + $sc);
            }
        }

        if(!$score && Session::get('num') == Session::get('quiz')->numquestion){
            $score = new Score();
            $score->topic = Session::get('quiz')->topic;
            $score->email = Session::get('admin')->email;
            if(Session::get('score')){
                $score->score = Session::get('score');
            }
            else{
                $score->score = 0;
            }
            $score->mark = Session::get('quiz')->mark;
            $score->numquestion = Session::get('quiz')->numquestion;

            $score->save();
        }
        elseif($score && Session::get('num') == Session::get('quiz')->numquestion){
            if(Session::get('score')){
                $score->score = Session::get('score');
            }
            else{
                $score->score = 0;
            }

            $score->update();
        }

        return redirect("/admin/respond1");
    }

    public function results(){
        $score = Score::where('topic', Session::get('quiz')->topic)->where('email', Session::get('admin')->email)->first();

        Session::forget('quiz');
        return view("admin.results")->with('score', $score);
    }
}
