<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Quiz;
use App\Models\Score;
use App\Models\Question;
use App\Models\Developer;

class UserController extends Controller
{
    //

    public function takequiz(){
        $quizzes = Quiz::get();
        $scores = Score::get();
        return view('user.takequiz')->with('quizzes', $quizzes)->with('scores', $scores);
    }

    public function history(){
        $scores = Score::where('email', Session::get('developer')->email)->get();
        return view('user.history')->with('scores', $scores);
    }

    public function ranking(){
        $developers = Developer::orderBy('score', 'desc')->get();
        return view('user.ranking')->with('developers', $developers);
    }

    public function respondquestion($topic){
        $num=1;
        if(!Session::get('num')){
            Session::put('num', 1);
        }
        else{
            $num = Session::get('num') + 1;
            Session::forget('num');
            Session::put('num', $num);
        }

        $quiz = Quiz::where('topic', $topic)->first();
        Session::put("quiz", $topic);
        
        if($num <= $quiz->num){
            return redirect("/user/assessments");
        }
        else{
            Session::forget('num');
            Session::forget('score');
            return redirect("/user/results");
        }
    }

    public function respondquestion1(){
        $num = Session::get('num') + 1;
        Session::forget('num');
        Session::put('num', $num);
       
        if($num <= Session::get('quiz')->num){
            return redirect("/user/assessments");
        }
        else{
            Session::forget('num');
            Session::forget('score');
            return redirect("/user/results");
        }
    }

    public function assessments(){
        $question = Question::where('topic', Session::get('quiz'))->where('numquestion', Session::get('num'))->first();

        return view('user.assessments')->with('question',$question);
    }

    public function saveanswer(Request $request){
        $score = Score::where('email', Session::get('developer')->email)->where('topic', Session::get('topic'))->first();

        // return Session::get('quiz');

        $quiz = Quiz::where('topic', Session::get('quiz'))->first();

        $developer = Developer::where('email', Session::get('developer')->email)->first();
        
        if($request->ans == $request->correct){
            if(!Session::get('score')){
                // return $quiz;
                Session::put('score', $quiz->mark);
            }
            else{
                $sc = Session::get('score');
                Session::forget('score');
                Session::put('score', $quiz->mark + $sc);
            }
        }

        if(!$score && Session::get('num') == $quiz->numquestion){
            $score = new Score();
            $score->topic = $quiz->topic;
            $score->email = Session::get('developer')->email;
            if(Session::get('score')){
                $score->score = Session::get('score');
            }
            else{
                $score->score = 0;
            }
            $score->mark = $quiz->mark;
            $score->numquestion = $quiz->numquestion;

            $developer->score = $developer->score + Session::get('score');

            $score->save();
            $developer->update();
        }
        elseif($score && Session::get('num') == $quiz->numquestion){
            $developer->score = ($developer->score - $score->score) + Session::get('score');
            if(Session::get('score')){
                $score->score = Session::get('score');
            }
            else{
                $score->score = 0;
            }

            $score->update();
            $developer->update();
        }

        return redirect("/user/respond1");
    }

    public function results(){
        $score = Score::where('topic', Session::get('topic'))->where('email', Session::get('developer')->email)->first();

        return view("user.results")->with('score', $score);
    }
}
