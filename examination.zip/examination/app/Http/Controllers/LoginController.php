<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Admin;
use App\Models\Developer;

class LoginController extends Controller
{
    //

    public function login(){
        return view('login.login');
    }

    public function adminaccess(Request $request){
        $admin = Admin::where('email', $request->email)->first();

        if ($admin) {
            if($admin->password == $request->password){
                Session::put('admin', $admin);
                return redirect("/admin/dashboard");
            }
            else{
                return back();
            }
        } else {
            return back();
        }
    }

    public function adminlogout(){
        Session::forget('admin');
        return redirect('/');
    }

    public function signup(Request $request){
        $developer = new Developer();
        $developer->name = $request->input('name');
        $developer->gender = $request->input('gender');
        $developer->college = $request->input('college');
        $developer->email = $request->input('email');
        $developer->phone = $request->input('phone');
        $developer->password = $request->input('password');
        $developer->score = 0;

        $developer->save();

        Session::put('developer', $developer);
        return redirect('/user/takequiz');
    }

    public function useraccess(Request $request){
        $developer = Developer::where('email', $request->email)->first();

        if ($developer) {
            if($developer->password == $request->password){
                Session::put('developer', $developer);
                return redirect("/user/takequiz");
            }
            else{
                return back();
            }
        } else {
            return back();
        }
    }

    public function userlogout(){
        Session::forget('developer');
        return redirect('/');
    }
}
