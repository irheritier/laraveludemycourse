

<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card w-100 text-center shadowBlue">
        <div class="card-header">
        All accounts
        </div>
        <?php if(Session::has("status")): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get("status")); ?>

            </div>
        <?php endif; ?>
        <div class="card-body">
        <table class="table table-bordered table-sm bg-dark text-white">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Holder Name</th>
            <th scope="col">Account No.</th>
            <th scope="col">Branch Name</th>
            <th scope="col">Current Balance</th>
            <th scope="col">Account type</th>
            <th scope="col">Contact</th>
            <th scope="col"></th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">1</th>
                    <td><?php echo e($account->name); ?></td>
                    <td><?php echo e($account->accountnumber); ?></td>
                    <td><?php echo e($account->branchname); ?></td>
                    <td>$ <?php echo e($account->balance); ?></td>
                    <td><?php echo e($account->accounttype); ?></td>
                    <td><?php echo e($account->phone); ?></td>
                    <td>
                        <a href="/manager/customerdetails/<?php echo e($account->id); ?>" class='btn btn-success btn-sm' data-toggle='tooltip' title="View More info">View</a>
                        <a href="/manager/notice/<?php echo e($account->id); ?>" class='btn btn-primary btn-sm' data-toggle='tooltip' title="Send notice to this">Send Notice</a>
                        <a href="/manager/deletecustomer/<?php echo e($account->id); ?>" class='btn btn-danger btn-sm' data-toggle='tooltip' title="Delete this account">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    <div class="card-footer text-muted">
        MCB Bank  
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank\resources\views/manager/home.blade.php ENDPATH**/ ?>