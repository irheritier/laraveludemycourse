

<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row w-100" style="padding: 11px">
        <div class="col">
        <div class="card text-center w-75 mx-auto">
        <div class="card-header">
        Account Information
        </div>
        <?php if(Session::has("status")): ?>
            <div class="alert alert-danger">
                <?php echo e(Session::get("status")); ?>

            </div>
        <?php endif; ?>
        <?php if(Session::has("status1")): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get("status1")); ?>

            </div>
        <?php endif; ?>
        <div class="card-body">
        <p class="card-text">      
            <form action="<?php echo e(url("/cashier/cashiertransfer")); ?> " method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="alert alert-success w-50 mx-auto">
                <h5>Enter Account Number</h5>
                <div class="form-group">
                    <input type="text" name="accountnumber" class="form-control " placeholder="Enter  Account number" required>
                </div>
                <button type="submit" name="get" class="btn btn-primary btn-bloc btn-sm my-1">Get Account Info</button>
                </div>
            </form>
        </p>
            </div>
        <div class="card-footer text-muted">
        MCB Bank  
        </div>
    </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank\resources\views/cashier/home.blade.php ENDPATH**/ ?>