<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="#">
       <img src="<?php echo e(asset('style/images/logo.png')); ?>" width="30" height="30" class="d-inline-block align-top" alt="">
      <!--  <i class="d-inline-block  fa fa-building fa-fw"></i> -->MCB Bank  </a>
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
     </button>
   
     <div class="collapse navbar-collapse" id="navbarSupportedContent">
       <ul class="navbar-nav mr-auto">
         <li class="nav-item ">
           <a class="nav-link <?php echo e(request()->is('manager') ? 'active' : ''); ?>" href="<?php echo e(url('/manager')); ?>">Home <span class="sr-only">(current)</span></a>
         </li>
         <li class="nav-item ">  <a class="nav-link <?php echo e(request()->is('manager/accounts') ? 'active' : ''); ?>" href="<?php echo e(url('/manager/accounts')); ?>">Accounts</a></li>
         <li class="nav-item ">  <a class="nav-link <?php echo e(request()->is('manager/addaccount') ? 'active' : ''); ?>" href="<?php echo e(url('/manager/addaccount')); ?>">Add New Account</a></li>
         <li class="nav-item ">  <a class="nav-link <?php echo e(request()->is('manager/feedback') ? 'active' : ''); ?>" href="<?php echo e(url('/manager/feedback')); ?>">Feedback</a></li>
       </ul>
       <form class="form-inline my-2 my-lg-0">
              <button class="btn btn-outline-success">Welecome Manager</button>
           <a href="" data-toggle="tooltip" title="Logout" class="btn btn-outline-danger mx-1" ><i class="fa fa-sign-out fa-fw"></i></a>    
       </form>    
     </div>
   </nav><br><br><br><?php /**PATH C:\xampp\htdocs\bank\resources\views/layout/navbar.blade.php ENDPATH**/ ?>