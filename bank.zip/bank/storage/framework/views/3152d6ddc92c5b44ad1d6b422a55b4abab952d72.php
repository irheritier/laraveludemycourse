

<?php $__env->startSection('title'); ?>
    Statements
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card  w-75 mx-auto">
        <div class="card-header text-center">
        Transaction made against you account
        </div>
        <div class="card-body">
        <?php $__currentLoopData = $statements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($statement->source == Session::get("customer")->accountnumber): ?>
                <?php if($statement->status == 0): ?>
                    <div class='alert alert-success'>You deposit $ <?php echo e($statement->amount); ?> in your account at <?php echo e($statement->created_at); ?></div>
                <?php elseif($statement->status == 1): ?>
                    <div class='alert alert-primary'>You have transfered $ <?php echo e($statement->amount); ?> from your account to <?php echo e($statement->destination); ?> at <?php echo e($statement->created_at); ?></div>
                <?php elseif($statement->status == 3): ?>
                    <div class='alert alert-secondary'>You withdraw $ <?php echo e($statement->amount); ?> in your account at <?php echo e($statement->created_at); ?></div>
                <?php endif; ?>
            <?php else: ?>
                <?php if($statement->destination == Session::get("customer")->accountnumber && $statement->status == 2): ?>
                    <div class='alert alert-warning'>You received $ <?php echo e($statement->amount); ?> from <?php echo e($statement->source); ?> at <?php echo e($statement->created_at); ?></div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <div class="card-footer text-muted">
        MCB Bank  
        </div>
        </div>
    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank\resources\views/customer/statements.blade.php ENDPATH**/ ?>