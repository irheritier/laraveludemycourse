;

<?php $__env->startSection('title'); ?>
    Notice
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card  w-75 mx-auto">
        <div class="card-header text-center">
        Notification from Bank
        </div>
        <div class="card-body">
        <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class='alert alert-success'><?php echo e($notice->message); ?> </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> 
        <div class="card-footer text-muted">
        MCB Bank  </div>
    </div>
    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank\resources\views/customer/notice.blade.php ENDPATH**/ ?>