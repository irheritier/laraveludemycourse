

<?php $__env->startSection('title'); ?>
    Add a new account
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card w-100 text-center shadowBlue">
    <div class="card-header">
     New Account Forum
    </div>
    <div class="card-body bg-dark text-white">
      <?php if(count($errors)>0): ?>
          <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
      <?php endif; ?>
      <?php if(Session::has("status")): ?>
          <div class="alert alert-success">
            <?php echo e(Session::get("status")); ?>

          </div>
      <?php endif; ?>
      <table class="table">
        <tbody>
          <tr>
            <form action="<?php echo e(url("/manager/createcustomer")); ?>" enctype="multipart/form-data"  method="POST">
              <?php echo e(csrf_field()); ?>

              <th>Name</th>
              <td><input type="text" name="name" class="form-control input-sm" required></td>
              <th>CNIC</th>
              <td><input type="number" name="cnic" class="form-control input-sm" required maxlength="8"></td>
          </tr>
          <tr>
              <th>Account Number</th>
              <td><input type="" name="accountnumber" readonly value="<?php echo e(time()); ?>" class="form-control input-sm" required></td>
              <th>Account Type</th>
              <td>
                <select class="form-control input-sm" name="accounttype" required>
                  <option value="current" selected>Current</option>
                  <option value="saving" selected>Saving</option>
                </select>
              </td>
          </tr>
          <tr>
              <th>City</th>
              <td><input type="text" name="city" class="form-control input-sm" required></td>
              <th>Address</th>
              <td><input type="text" name="address" class="form-control input-sm" required></td>
          </tr>
          <tr>
              <th>Email</th>
              <td><input type="email" name="email" class="form-control input-sm" required></td>
              <th>Password</th>
              <td><input type="password" name="password" class="form-control input-sm" required minlength="6"></td>
          </tr>
          <tr>
              <th>Deposit</th>
              <td><input type="number" name="balance" min="500" class="form-control input-sm" required></td>
              <th>Source of income</th>
              <td><input type="text" name="source" class="form-control input-sm" required></td>
          </tr>
          <tr>
              <th>Contact Number</th>
              <td><input type="number" name="number"  class="form-control input-sm" required></td>
              <th>Photo</th>
              <td>
                <input type="file" name="image"  class="form-control input-sm" required>
              </td>
          </tr>
          <tr>
            <td colspan="4">
              <button type="submit" name="saveAccount" class="btn btn-primary btn-sm">Save Account</button>
              <button type="Reset" class="btn btn-secondary btn-sm">Reset</button>
            </form>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="card-footer text-muted">
      MCB Bank  
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank\resources\views/manager/addaccount.blade.php ENDPATH**/ ?>