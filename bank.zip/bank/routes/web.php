<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ManagerController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CashierController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Login page

Route::get('/', [LoginController::class, 'login']);
Route::post('/customeraccess', [LoginController::class, 'customeraccess']);
Route::get('/customerlogout', [LoginController::class, 'customerlogout']);
Route::post('/cashier/cashieraccess', [LoginController::class, 'cashieraccess']);
Route::get('/cashier/cashierlogout', [LoginController::class, 'cashierlogout']);

// Manager Pages

Route::get('/manager', [ManagerController::class, 'home']);
Route::get('/manager/accounts', [ManagerController::class, 'accounts']);
Route::get('/manager/addaccount', [ManagerController::class, 'addaccount']);
Route::get('/manager/feedback', [ManagerController::class, 'feedback']);
Route::post('/manager/createcashier', [ManagerController::class, 'createcashier']);
Route::post('/manager/updatecashier', [ManagerController::class, 'updatecashier']);
Route::get('/manager/deletecashier/{id}', [ManagerController::class, 'deletecashier']);
Route::post('/manager/createcustomer', [ManagerController::class, 'createcustomer']);
Route::get('/manager/customerdetails/{id}', [ManagerController::class, 'customerdetails']);
Route::get('/manager/notice/{id}', [ManagerController::class, 'notice']);
Route::post('/manager/sendnotice', [ManagerController::class, 'sendnotice']);
Route::get('/manager/deletecustomer/{id}', [ManagerController::class, 'deletecustomer']);

// Clients pages

Route::get('/customer', [CustomerController::class, 'customer']);
Route::get('/customer/account', [CustomerController::class, 'account']);
Route::get('/customer/statements', [CustomerController::class, 'statements']);
Route::get('/customer/transfer', [CustomerController::class, 'transfer']);
Route::get('/customer/notice', [CustomerController::class, 'notice']);
Route::get('/customer/feedback', [CustomerController::class, 'feedback']);
Route::post('/sendmestomanager', [CustomerController::class, 'sendmestomanager']);
Route::post('/customer/customertransfer', [CustomerController::class, 'customertransfer']);
Route::post('/customer/validatetransfer', [CustomerController::class, 'validatetransfer']);

// Cashier Pages

Route::get('/cashier', [CashierController::class, 'cashier']);
Route::post('/cashier/cashiertransfer', [CashierController::class, 'cashiertransfer']);
Route::post('/cashier/customerwithdraw', [CashierController::class, 'customerwithdraw']);
Route::post('/cashier/cashierdeposit', [CashierController::class, 'cashierdeposit']);