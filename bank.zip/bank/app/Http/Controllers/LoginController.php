<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Account;
use App\Models\Cashier;

class LoginController extends Controller
{
    //

    public function login(){
        if(Session::has("customer")){
            return redirect("/customer");
        }
        elseif(Session::has("manager")){

        }
        elseif(Session::has("cashier")){
            return redirect("/cashier");
        }
        else{
            return view('login.login');
        }
    }

    public function customeraccess(Request $request){
        $account = Account::where("email", $request->email)->first();

        if($account){
            if($account->password == $request->password){
                Session::put("customer", $account);
                return redirect("/customer");
            }
            else{
                return back()->with('status', 'Wrong email or password');
            }
        }
        else{
            return back()->with('status', 'Wrong email or password');
        }
    }

    public function customerlogout(){
        Session::forget("customer");
        return redirect("/");
    }

    public function cashieraccess(Request $request){
        $cashier = Cashier::where("email", $request->email)->first();

        if($cashier){
            if($cashier->password == $request->password){
                Session::put("cashier", $cashier);
                return redirect("/cashier");
            }
            else{
                return back()->with('status', 'Wrong email or password');
            }
        }
        else{
            return back()->with('status', 'Wrong email or password');
        }
    }

    public function cashierlogout(){
        Session::forget("cashier");
        return redirect("/");
    }
}
