<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Cashier;
use App\Models\Account;
use App\Models\Statement;
use App\Models\Notice;
use App\Models\Feedback;

class ManagerController extends Controller
{
    //

    public function home(){
        $accounts = Account::get();
        return view('manager.home')->with("accounts", $accounts);
    }

    public function accounts(){
        $cashiers = Cashier::get();
        return view('manager.accounts')->with("cashiers", $cashiers);
    }

    public function addaccount(){
        return view('manager.addaccount');
    }

    public function feedback(){
        $feedbacks = Feedback::All();
        return view('manager.feedback')->with("feedbacks", $feedbacks);
    }

    public function createcashier(Request $request){
        $cashier = new Cashier();
        $cashier->email = $request->input("email");
        $cashier->password = $request->input("password");
        $cashier->accounttype = "Cashier";

        $cashier->save();
        return back()->with("status", "Cashier account successfully created !!!");
    }

    public function updatecashier(Request $request){
        $cashier = Cashier::find($request->id);
        $cashier->email = $request->input("email");
        $cashier->password = $request->input("password");

        $cashier->update();

        return back()->with("status", "Cashier successfully updated");
    }

    public function deletecashier($id){
        $cashier = Cashier::find($id);
        $cashier->delete();

        return back()->with("status", "Cashier successfully deleted");
    }

    public function createcustomer(Request $request){
        $this->validate($request, [
            'image' => 'image|max:1999'
        ]);

        $fileNameWithExt = $request->file("image")->getClientOriginalName();
        $fileName = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
        $ext = $request->file("image")->getClientOriginalExtension();
        $fileNamaToStore = $fileName."_".time().'.'.$ext;
        
        $account = new Account();
        $account->name = $request->input("name");
        $account->accountnumber = $request->input("accountnumber");
        $account->city = $request->input("city"); 
        $account->email = $request->input("email");
        $account->balance = $request->input("balance");
        $account->phone = $request->input("number"); 
        $account->cnic = $request->input("cnic");
        $account->accounttype = $request->input("accounttype");
        $account->address = $request->input("address");
        $account->password = $request->input("password");
        $account->source = $request->input("source");
        $account->photo = $fileNamaToStore;
        $account->source = $request->input("source");
        $account->branchname = "Equity Bank";
        $account->branchcode = 111112222;
        
        $statement = new Statement();
        $statement->name = $request->input("name");
        $statement->source = $request->input("accountnumber");
        $statement->destination = $request->input("accountnumber");
        $statement->amount = $request->input("balance");
        $statement->status = 0;

        $account->save();
        $statement->save();

        // upload image in laravel project.
        $path = $request->file("image")->storeAs('public/account_images', $fileNamaToStore);

        return back()->with("status", "The customer account successfully created !!!");
        
    }

    public function customerdetails($id){
        $account = Account::find($id);

        return view('manager.customerdetails')->with("account", $account);
    }

    public function notice($id){
        $account = Account::find($id);
        return view('manager.notice')->with('account', $account);
    }

    public function sendnotice(Request $request){
        $notice = new Notice();
        $notice->message = $request->input("notice");
        $notice->accountnumber = $request->input("accountnumber");

        $notice->save();
        return back()->with("status", "Notice successfully sent");
    }

    public function deletecustomer($id){
        $account = Account::find($id);
        Storage::delete('public/account_images/'.$account->photo);
        $account->delete();

        return back()->with("status", "The account has been successfully deleted");
    }
}
