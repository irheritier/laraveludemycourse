<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Account;
use App\Models\Statement;

class CashierController extends Controller
{
    //

    public function cashier(){
        return view('cashier.home');
    }

    public function cashiertransfer(Request $request){
        $account = Account::where("accountnumber", $request->accountnumber)->first();

        if($account){
            return view("cashier.transaction")->with("account", $account);
        }
        else{
            return back()->with("status", "This account number does not exist");
        }
    }

    public function customerwithdraw(Request $request){
        
        $account = Account::where("accountnumber", $request->input("accountnumber"))->first();
        $account->balance = $account->balance - $request->input('amount');
        $account->update();

        $statement = new Statement();
        $statement->name = $request->input("name");
        $statement->source = $request->input("accountnumber");
        $statement->destination = $request->input("accountnumber");
        $statement->amount = $request->input("amount");
        $statement->status = 3;

        $statement->save();

        return redirect("/cashier")->with("status1", "The withdraw has been successfully accomplished");
    }

    public function cashierdeposit(Request $request){
        $account = Account::where("accountnumber", $request->input("accountnumber"))->first();
        $account->balance = $account->balance + $request->input('amount');
        $account->update();

        $statement = new Statement();
        $statement->name = $request->input("name");
        $statement->source = $request->input("accountnumber");
        $statement->destination = $request->input("accountnumber");
        $statement->amount = $request->input("amount");
        $statement->status = 0;

        $statement->save();

        return redirect("/cashier")->with("status1", "The Deposit has been successfully accomplished");
    }
}
