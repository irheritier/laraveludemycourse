<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Notice;
use App\Models\Feedback;
use App\Models\Account;
use App\Models\Statement;

class CustomerController extends Controller
{
    //

    public function customer(){
        return view('customer.home');
    }

    public function account(){
        return view('customer.account');
    }

    public function statements(){
        $statements = Statement::get();

        return view('customer.statements')->with("statements", $statements);
    }

    public function transfer(){
        return view('customer.transfer');
    }

    public function notice(){
        $notices = Notice::where("accountnumber", Session::get("customer")->accountnumber)->get();
        return view('customer.notice')->with("notices", $notices);
    }

    public function feedback(){
        return view('customer.feedback');
    }

    public function sendmestomanager(Request $request){
        $feedback = new Feedback();
        $feedback->name = Session::get("customer")->name;
        $feedback->accountnumber = Session::get("customer")->accountnumber;
        $feedback->phone = Session::get("customer")->phone;
        $feedback->message = $request->message;

        $feedback->save();

        return back()->with("status", "Message successfully sent to the bank");
    }

    public function customertransfer(Request $request){
        $account = Account::where("accountnumber", $request->accountnumber)->first();

        if($account){
            if ($account->accountnumber != Session::get("customer")->accountnumber) {
                return view("customer.transfer1")->with("account", $account);
            } else {
                return back()->with("status", "You have to transfer only to another account");
            }
            
        }
        else{
            return back()->with("status", "This account does not exist");
        }
    }

    public function validatetransfer(Request $request){
        
        $account = Account::where("accountnumber", Session::get("customer")->accountnumber)->first();
        $account1 = Account::where("accountnumber", $request->accountnumber)->first();

        $account->balance = $account->balance - $request->amount;
        $account->update();

        $account1->balance = $account1->balance + $request->amount;
        $account1->update();

        $statement = new Statement();
        $statement->name = $account->name;
        $statement->source = $account->accountnumber;
        $statement->destination = $account1->accountnumber;
        $statement->amount = $request->amount;
        $statement->status = 1;

        $statement->save();

        $statement = new Statement();
        $statement->name = $account1->name;
        $statement->source = $account->accountnumber;
        $statement->destination = $account1->accountnumber;
        $statement->amount = $request->amount;
        $statement->status = 2;

        $statement->save();

        Session::put("customer", $account);

        return redirect("/customer/transfer")->with("status1", "Your transfer has been successfully sent");

    }

}
