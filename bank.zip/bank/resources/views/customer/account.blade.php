@extends('layout.master1')

@section('title')
    Account
@endsection

@section('content')
<div class="container">
    <div class="card  w-75 mx-auto">
    <div class="card-header text-center">
      Your account Information
    </div>
    <div class="card-body">
        <div class="text-center">
            <img src="/storage/account_images/{{Session::get("customer")->photo}}" height="150" width="150" alt="" class="rounded-circle m-2" style="border : 5px solid#555;">
        </div>
        <table class="table table-striped table-dark w-75 mx-auto">
          <thead>
            <tr>
              <td scope="col">Account No.</td>
              <th scope="col">{{Session::get("customer")->accountnumber}}</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Branch</th>
              <td>{{Session::get("customer")->branchname}}</td>
            </tr>
            <tr>
              <th scope="row">Branch Code</th>
              <td>{{Session::get("customer")->branchcode}}</td>
            </tr>
            <tr>
              <th scope="row">Account Type</th>
              <td>{{Session::get("customer")->accounttype}}</td>
            </tr>
            <tr>
              <th scope="row">Account Created</th>
              <td>{{Session::get("customer")->created_at}}</td>
            </tr>
          </tbody>
        </table>
        
    </div>
    <div class="card-footer text-muted">
     MCB Bank  </div>
  </div>
  
  </div>
@endsection