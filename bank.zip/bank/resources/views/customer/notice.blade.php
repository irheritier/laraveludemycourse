@extends('layout.master1');

@section('title')
    Notice
@endsection

@section('content')
    <div class="container">
        <div class="card  w-75 mx-auto">
        <div class="card-header text-center">
        Notification from Bank
        </div>
        <div class="card-body">
        @foreach ($notices as $notice)
            <div class='alert alert-success'>{{$notice->message}} </div>  
        @endforeach
        </div> 
        <div class="card-footer text-muted">
        MCB Bank  </div>
    </div>
    
    </div>
@endsection