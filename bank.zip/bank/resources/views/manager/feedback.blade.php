@extends('layout.master')

@section('title')
    Feedback
@endsection

@section('content')
<div class="card w-100 text-center shadowBlue">
    <div class="card-header">
      Feedback from Account Holder
    </div>
    <div class="card-body">
     <table class="table table-bordered table-sm bg-dark text-white">
    <thead>
      <tr>
        <th scope="col">From</th>
        <th scope="col">Account No.</th>
        <th scope="col">Contact</th>
        <th scope="col">Message</th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      @foreach ($feedbacks as $feedback)
        <tr>
          <td>{{$feedback->name}}</td>
          <td>{{$feedback->accountnumber}}</td>
          <td>{{$feedback->phone}}</td>
          <td>{{$feedback->message}}</td>
          <td>
            <a href="" class='btn btn-danger btn-sm' data-toggle='tooltip' title="Delete this Message">Delete</a>
          </td>
        </tr>    
      @endforeach
    </tbody>
  </table>
    <div class="card-footer text-muted">
      MCB Bank  </div>
  </div>
@endsection