@extends('layout.master')

@section('title')
    Cashiers accounts
@endsection

@section('content')
<div class="card w-100 text-center shadowBlue">
    <div class="card-header">
      All Staff Accounts <button class="btn btn-outline-success btn-sm float-right" data-toggle="modal" data-target="#exampleModal">Add New Account</button>
    </div>
    <div class="card-body bg-dark text-white">
      @if (Session::has("status"))
          <div class="alert alert-success">
              {{Session::get("status")}}
          </div>
      @endif
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Email</th>
            <th>Password</th>
            <th>Account Type</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          @foreach ($cashiers as $cashier)
            <tr>
              <td>{{$cashier->email}}</td><td>{{$cashier->password}}</td><td>{{$cashier->accounttype}}</td>
              <td>
                <a href='' class='btn btn-primary btn-sm' data-toggle="modal" data-target="#exampleModalUpdate{{$cashier->id}}">Edit</a>
                <a href='/manager/deletecashier/{{$cashier->id}}' class='btn btn-danger btn-sm'>Delete</a>
              </td>
            </tr>
          @endforeach
        </tbody>
         </table>
    </div>
    <div class="card-footer text-muted">
        MCB Bank  
        </div>
  </div>

  <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content bg-dark text-white">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">New Cashier Account</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         <form action="{{url('/manager/createcashier')}}" method="POST">
            {{ csrf_field() }}
            <div class="form-group">
              <input class="form-control w-75 mx-auto" type="email" name="email" required placeholder="Email">
            </div>
            <div class="form-group">
              <input class="form-control w-75 mx-auto" type="password" name="password" required placeholder="Password" minlength="4">
            </div>
        </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="saveAccount" class="btn btn-primary">Save Account</button>
        </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal Update -->
  @foreach ($cashiers as $cashier)
    <div class="modal fade" id="exampleModalUpdate{{$cashier->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content bg-dark text-white">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit Cashier Account</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
          <form action="{{url('/manager/updatecashier')}}" method="POST">
              {{ csrf_field() }}
              <div class="form-group">
                <input type="hidden" value="{{$cashier->id}}" name="id">
                <input class="form-control w-75 mx-auto" type="email" name="email" required placeholder="Email" value="{{$cashier->email}}">
              </div>
              <div class="form-group">
                <input class="form-control w-75 mx-auto" type="password" name="password" required placeholder="Password" minlength="4" value="{{$cashier->password}}">
              </div>
          </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" name="saveAccount" class="btn btn-primary">Update Account</button>
          </form>
          </div>
        </div>
      </div>
    </div>   
  @endforeach
@endsection